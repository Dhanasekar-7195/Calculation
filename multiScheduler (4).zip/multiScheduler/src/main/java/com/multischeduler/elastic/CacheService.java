//package com.multischeduler.elastic;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.stereotype.Service;
//
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//
//@Service
//public class CacheService {
//
//	@Autowired
//	private RedisTemplate<String, Object> redisTemplate;
//
//	public Map<String, String> getAllData() {
//		Set<String> keys = redisTemplate.keys("*"); // Get all keys
//		Map<String, String> data = new HashMap<>();
//
//		if (keys != null && !keys.isEmpty()) {
//			for (String key : keys) {
//				Object value = redisTemplate.opsForValue().get(key);
//				if (value != null) {
//					data.put(key, value.toString());
//				} else {
//					data.put(key, "null");
//				}
//			}
//		} else {
//			data.put("message", "No data found in Redis.");
//		}
//
//		return data;
//	}
//
//	public String getValueByKey(String key) {
//		Object value = redisTemplate.opsForValue().get(key);
//		return value != null ? value.toString() : "Key not found!";
//	}
//}
