//package com.multischeduler.elastic;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.Map;
//
//@RestController
//public class CacheController {
//
//	@Autowired
//	private CacheService cacheService;
//	
//	@Autowired
//    private RedisTemplate<String, String> redisTemplate;
//
//	@GetMapping("/fetchAll")
//	public Map<String, String> fetchAllData() {
//		return cacheService.getAllData();
//	}
//	
//	 @GetMapping("/ping")
//	    public String ping() {
//	        try {
//	            redisTemplate.opsForValue().set("testKey", "Hello, Redis!");
//	            String value = redisTemplate.opsForValue().get("testKey");
//	            return value != null ? "Connection successful: " + value : "Failed to fetch value";
//	        } catch (Exception e) {
//	            return "Connection failed: " + e.getMessage();
//	        }
//	    }
//	 
//	 @GetMapping("/fetch/{key}")
//	    public String fetchValueByKey(@PathVariable String key) {
//	        return cacheService.getValueByKey(key);
//	    }
//	
//	
//}
