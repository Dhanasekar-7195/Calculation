//package com.multischeduler.kinesistoredis;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/kinesis")
//public class KinesisController3 {
//
//	@Autowired
//	private KinesisConsumerService3 consumerService;
//
//	@GetMapping("/fetch")
//	public String fetchData() {
//		consumerService.fetchAndStoreRecords();
//		return "Data fetched from Kinesis and stored in Redis.";
//	}
//	
//	 @GetMapping("/data")
//	    public List<String> getStoredData() {
//	        return consumerService.getStoredRecords();
//	    }
//}
