////package com.multischeduler.kinesistoredis;
////
////import java.nio.charset.StandardCharsets;
////import java.time.Duration;
////import java.util.ArrayList;
////import java.util.List;
////
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.data.redis.core.StringRedisTemplate;
////import org.springframework.data.redis.core.ListOperations;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.RestController;
////
////import software.amazon.awssdk.services.kinesis.KinesisClient;
////import software.amazon.awssdk.services.kinesis.model.*;
////
////@RestController
////public class KinesisRedisController {
////
////	@Autowired
////	private KinesisClient kinesisClient;
////
////	@Autowired
////	private StringRedisTemplate redisTemplate;
////
////	private static final String STREAM_NAME = "kiteconnect-data";
////	private static final String REDIS_KEY = "kinesis_data";
////	private static final int RECORD_LIMIT = 5; // Fetch fewer records
////	private static final Duration TIMEOUT = Duration.ofSeconds(10); // Set a timeout
////
////	@GetMapping("/fetch-kinesis")
////	public List<String> fetchAndStoreKinesisData() {
////		List<String> recordsData = new ArrayList<>();
////		ListOperations<String, String> ops = redisTemplate.opsForList();
////
////		List<String> shardIds = getShardIds();
////
////		for (String shardId : shardIds) {
////			String shardIterator = getShardIterator(shardId);
////			long startTime = System.currentTimeMillis();
////
////			while (shardIterator != null) {
////				if (Duration.ofMillis(System.currentTimeMillis() - startTime).compareTo(TIMEOUT) > 0) {
////					System.out.println("Timeout reached. Stopping record fetch.");
////					break;
////				}
////
////				GetRecordsRequest recordsRequest = GetRecordsRequest.builder().shardIterator(shardIterator)
////						.limit(RECORD_LIMIT).build();
////
////				GetRecordsResponse recordsResponse = kinesisClient.getRecords(recordsRequest);
////
////				if (recordsResponse.records().isEmpty()) {
////					System.out.println("No records found. Waiting before next poll...");
////					try {
////						Thread.sleep(2000); // Wait before polling again
////					} catch (InterruptedException e) {
////						Thread.currentThread().interrupt();
////					}
////				}
////
////				for (software.amazon.awssdk.services.kinesis.model.Record record : recordsResponse.records()) {
////					String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
////					recordsData.add(data);
////					ops.rightPush(REDIS_KEY, data); // Push to Redis list
////					System.out.println("Record added to Redis: " + data);
////				}
////
////				shardIterator = recordsResponse.nextShardIterator();
////			}
////		}
////
////		return recordsData;
////	}
////
////	private List<String> getShardIds() {
////		ListShardsRequest listShardsRequest = ListShardsRequest.builder().streamName(STREAM_NAME).build();
////
////		ListShardsResponse listShardsResponse = kinesisClient.listShards(listShardsRequest);
////
////		List<String> shardIds = new ArrayList<>();
////		listShardsResponse.shards().forEach(shard -> shardIds.add(shard.shardId()));
////		return shardIds;
////	}
////
////	private String getShardIterator(String shardId) {
////		GetShardIteratorRequest shardIteratorRequest = GetShardIteratorRequest.builder().streamName(STREAM_NAME)
////				.shardId(shardId).shardIteratorType(ShardIteratorType.TRIM_HORIZON).build();
////
////		GetShardIteratorResponse shardIteratorResponse = kinesisClient.getShardIterator(shardIteratorRequest);
////		return shardIteratorResponse.shardIterator();
////	}
//
//
//
//
//
//
////}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//package com.multischeduler.kinesistoredis;
//
//import java.nio.charset.StandardCharsets;
//import java.time.LocalTime;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.ListOperations;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import software.amazon.awssdk.services.kinesis.KinesisClient;
//import software.amazon.awssdk.services.kinesis.model.*;
//
//@RestController
//@Component
//public class KinesisRedisController {
//
//    @Autowired
//    private KinesisClient kinesisClient;
//
//    @Autowired
//    private StringRedisTemplate redisTemplate;
//
//    private static final String STREAM_NAME = "kiteconnect-data";
//    private static final String REDIS_KEY = "kinesis_data";
//
//    private static final LocalTime MARKET_OPEN = LocalTime.of(9, 15);
//    private static final LocalTime MARKET_CLOSE = LocalTime.of(15, 30);
//
//    @GetMapping("/fetch-kinesis")
//    public List<String> fetchData() {
//        return fetchLiveData();
//    }
//
//      //@Scheduled(fixedRate = 2000) // Every 2 seconds
//    @Scheduled(fixedRate = 60000) // Every 1 minute
//    public void scheduleDataFetch() {
//        LocalTime now = LocalTime.now();
//        if (now.isAfter(MARKET_OPEN) && now.isBefore(MARKET_CLOSE)) {
//            System.out.println("Fetching live data from Kinesis at: " + now);
//            fetchLiveData();
//        } else {
//            System.out.println("Market closed. Scheduler not fetching live data.");
//        }
//    }
//
//    private List<String> fetchLiveData() {
//        List<String> recordsData = new ArrayList<>();
//        ListOperations<String, String> ops = redisTemplate.opsForList();
//
//        List<String> shardIds = getShardIds();
//        for (String shardId : shardIds) {
//            String shardIterator = getShardIterator(shardId);
//            while (shardIterator != null) {
//                GetRecordsRequest recordsRequest = GetRecordsRequest.builder()
//                        .shardIterator(shardIterator)
//                          .limit(10)
//                        .limit(600)
//                        .build();
//
//                GetRecordsResponse recordsResponse = kinesisClient.getRecords(recordsRequest);
//
//                for (software.amazon.awssdk.services.kinesis.model.Record record : recordsResponse.records()) {
//                    String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//                    recordsData.add(data);
//                    ops.rightPush(REDIS_KEY, data); // Store live data in Redis
//                }
//
//                shardIterator = recordsResponse.nextShardIterator();
//            }
//        }
//
//        return recordsData;
//    }
//
//    private List<String> getShardIds() {
//        ListShardsRequest listShardsRequest = ListShardsRequest.builder().streamName(STREAM_NAME).build();
//        ListShardsResponse listShardsResponse = kinesisClient.listShards(listShardsRequest);
//        List<String> shardIds = new ArrayList<>();
//        listShardsResponse.shards().forEach(shard -> shardIds.add(shard.shardId()));
//        return shardIds;
//    }
//
//    private String getShardIterator(String shardId) {
//        GetShardIteratorRequest shardIteratorRequest = GetShardIteratorRequest.builder()
//                .streamName(STREAM_NAME)
//                .shardId(shardId)
//                .shardIteratorType(ShardIteratorType.TRIM_HORIZON)
//                .build();
//
//        GetShardIteratorResponse shardIteratorResponse = kinesisClient.getShardIterator(shardIteratorRequest);
//        return shardIteratorResponse.shardIterator();
//    }
//    
//    
//    
//    
//    @GetMapping("/fetch-redis")
//    public List<String> fetchDataFromRedis() {
//        ListOperations<String, String> ops = redisTemplate.opsForList();
//        return ops.range(REDIS_KEY, 0, -1); // Fetch all elements from Redis list
//    }
//} 
//
//	// 🚀 Now, your API will:
//	// ✅ Fetch **live data from Kinesis** during market hours (9:15 AM – 3:30 PM)
//	// ✅ **Cache the data in Redis** while the market is open
//	// ✅ **Fetch historical data from Redis** after market closes (3:30 PM onward)
//
//	// Let me know if you’d like me to tweak anything or add more optimizations! 🔧
//
//
