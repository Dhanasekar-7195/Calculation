//package com.multischeduler.kinesistoredis;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Service;
//import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
//import software.amazon.awssdk.regions.Region;
//import software.amazon.awssdk.services.kinesis.KinesisClient;
//import software.amazon.awssdk.services.kinesis.model.*;
//
//import java.nio.charset.StandardCharsets;
//import java.util.List;
//
//@Service
//public class KinesisConsumerService {
//
//    private final KinesisClient kinesisClient;
//    private final StringRedisTemplate redisTemplate;
//    private final String streamName;
//
//    public KinesisConsumerService(@Value("${aws.kinesis.stream-name}") String streamName,
//                                  @Value("${aws.kinesis.region}") String region,
//                                  StringRedisTemplate redisTemplate) {
//        this.kinesisClient = KinesisClient.builder()
//                .region(Region.of(region))
//                .credentialsProvider(DefaultCredentialsProvider.create())
//                .build();
//        this.redisTemplate = redisTemplate;
//        this.streamName = streamName;
//    }
//
//    public void fetchAndStoreRecords() {
//        String shardIterator = getShardIterator();
//        while (shardIterator != null) {
//            GetRecordsResponse response = kinesisClient.getRecords(GetRecordsRequest.builder()
//                    .shardIterator(shardIterator)
//                    .limit(10)
//                    .build());
//
//            List<Record> records = response.records();
//            for (Record record : records) {
//                String data = StandardCharsets.UTF_8.decode(record.data()).toString();
//                redisTemplate.opsForList().rightPush("kinesisData", data);
//            }
//
//            shardIterator = response.nextShardIterator();
//            if (records.isEmpty()) break; // Exit loop if no more data
//        }
//    }
//
//    private String getShardIterator() {
//        ListShardsResponse shardsResponse = kinesisClient.listShards(ListShardsRequest.builder()
//                .streamName(streamName)
//                .build());
//
//        if (!shardsResponse.shards().isEmpty()) {
//            String shardId = shardsResponse.shards().get(0).shardId();
//            GetShardIteratorRequest iteratorRequest = GetShardIteratorRequest.builder()
//                    .streamName(streamName)
//                    .shardId(shardId)
//                    .shardIteratorType(ShardIteratorType.TRIM_HORIZON)
//                    .build();
//            return kinesisClient.getShardIterator(iteratorRequest).shardIterator();
//        }
//        return null;
//    }
//}
//
