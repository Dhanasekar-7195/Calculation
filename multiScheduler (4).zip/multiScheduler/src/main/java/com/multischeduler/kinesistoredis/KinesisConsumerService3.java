//package com.multischeduler.kinesistoredis;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Service;
//
//import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
//import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
//import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
//import software.amazon.awssdk.regions.Region;
//import software.amazon.awssdk.services.kinesis.KinesisClient;
//import software.amazon.awssdk.services.kinesis.model.*;
//
//import java.nio.charset.StandardCharsets;
//import java.util.List;
//
//@Service
//public class KinesisConsumerService3 {
//
//    private final KinesisClient kinesisClient;
//    @Autowired
//    private RedisTemplate<String, String> redisTemplate;
//    private final String streamName;
//
//    public KinesisConsumerService3(
//            @Autowired RedisTemplate<String, String> redisTemplate,
//            @Value("${aws.accessKey}") String accessKey,
//            @Value("${aws.secretKey}") String secretKey,
//            @Value("${aws.region}") String region,
//            @Value("${aws.kinesis.streamName}") String streamName) {
//
//        this.redisTemplate = redisTemplate;
//
//        this.kinesisClient = KinesisClient.builder()
//                .region(Region.of(region))
//                .credentialsProvider(StaticCredentialsProvider.create(
//                        AwsBasicCredentials.create(accessKey, secretKey)))
//                .build();
//
//        this.streamName = streamName;
//    }
//
//    public void fetchAndStoreRecords() {
//        String shardIterator = getShardIterator();
//        while (shardIterator != null) {
//            GetRecordsResponse response = kinesisClient.getRecords(GetRecordsRequest.builder()
//                    .shardIterator(shardIterator)
//                    .limit(10)
//                    .build());
//
//            List<software.amazon.awssdk.services.kinesis.model.Record> records = response.records();
//            for (software.amazon.awssdk.services.kinesis.model.Record record : records) {
//                String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//                redisTemplate.opsForList().rightPush("kinesisData", data);
//            }
//
//
//            shardIterator = response.nextShardIterator();
//            if (records.isEmpty()) break; // Exit loop if no more data
//        }
//    }
//
//    private String getShardIterator() {
//        ListShardsResponse shardsResponse = kinesisClient.listShards(ListShardsRequest.builder()
//                .streamName(streamName)
//                .build());
//
//        if (!shardsResponse.shards().isEmpty()) {
//            String shardId = shardsResponse.shards().get(0).shardId();
//            GetShardIteratorRequest iteratorRequest = GetShardIteratorRequest.builder()
//                    .streamName(streamName)
//                    .shardId(shardId)
//                    .shardIteratorType(ShardIteratorType.TRIM_HORIZON)
//                    .build();
//            return kinesisClient.getShardIterator(iteratorRequest).shardIterator();
//        }
//        return null;
//    }
//
//	public List<String> getStoredRecords() {
//        return redisTemplate.opsForList().range("kinesisData", 0, -1);
//
//	}
//}
//
