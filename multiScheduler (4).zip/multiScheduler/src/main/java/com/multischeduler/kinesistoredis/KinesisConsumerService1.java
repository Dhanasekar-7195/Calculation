//package com.multischeduler.kinesistoredis;
//
//import java.nio.charset.StandardCharsets;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
//import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
//import software.amazon.awssdk.regions.Region;
//import software.amazon.awssdk.services.kinesis.KinesisClient;
//import software.amazon.awssdk.services.kinesis.model.DescribeStreamRequest;
//import software.amazon.awssdk.services.kinesis.model.DescribeStreamResponse;
//import software.amazon.awssdk.services.kinesis.model.GetRecordsRequest;
//import software.amazon.awssdk.services.kinesis.model.GetRecordsResponse;
//import software.amazon.awssdk.services.kinesis.model.GetShardIteratorRequest;
//import software.amazon.awssdk.services.kinesis.model.GetShardIteratorResponse;
//import software.amazon.awssdk.services.kinesis.model.Shard;
//import software.amazon.awssdk.services.kinesis.model.ShardIteratorType;
//
//@Service
//public class KinesisConsumerService1 {
//
//	private final KinesisClient kinesisClient;
//	private final ObjectMapper objectMapper = new ObjectMapper();
//	private final String streamName;
//
//	@Autowired
//	public KinesisConsumerService1(@Value("${aws.accessKey}") String accessKey,
//			@Value("${aws.secretKey}") String secretKey, @Value("${aws.region}") String region,
//			@Value("${aws.kinesis.streamName}") String streamName) {
//		this.streamName = streamName;
//
//		this.kinesisClient = KinesisClient.builder().region(Region.of(region))
//				.credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey)))
//				.build();
//	}
//
//	// ALL RECORDS
//	public List<String> fetchAllDataFromKinesis() {
//		List<String> liveRecords = new ArrayList<>();
//
//		try {
//			DescribeStreamResponse describeStreamResponse = kinesisClient
//					.describeStream(DescribeStreamRequest.builder().streamName(streamName).build());
//
//			List<Shard> shards = describeStreamResponse.streamDescription().shards();
//
//			for (Shard shard : shards) {
//				String shardIterator = getShardIterator(shard.shardId());
//
//				while (shardIterator != null) {
//					GetRecordsResponse recordsResponse = kinesisClient
//							.getRecords(GetRecordsRequest.builder().shardIterator(shardIterator).limit(10) // Fetch 10
//																											// records
//																											// at a time
//									.build());
//
//					List<software.amazon.awssdk.services.kinesis.model.Record> records = recordsResponse.records();
//					for (software.amazon.awssdk.services.kinesis.model.Record record : records) {
//						String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//						liveRecords.add(data);
//					}
//
//					// Move to next batch of records
//					shardIterator = recordsResponse.nextShardIterator();
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return liveRecords;
//	}
//
//	private String getShardIterator(String shardId) {
//		GetShardIteratorRequest request = GetShardIteratorRequest.builder().streamName(streamName).shardId(shardId)
//				.shardIteratorType(ShardIteratorType.LATEST) // Fetch the latest records
//				.build();
//
//		GetShardIteratorResponse response = kinesisClient.getShardIterator(request);
//		return response.shardIterator();
//	}
//
//	// LIVE RECORDS STREAMING
//	public List<String> fetchLiveDataFromKinesis() {
//		List<String> liveRecords = new ArrayList<>();
//
//		try {
//			DescribeStreamResponse describeStreamResponse = kinesisClient
//					.describeStream(DescribeStreamRequest.builder().streamName(streamName).build());
//
//			List<Shard> shards = describeStreamResponse.streamDescription().shards();
//
//			for (Shard shard : shards) {
//				String shardIterator = getShardIterator(shard.shardId());
//
//				while (true) { // Infinite loop to keep polling live data
//					GetRecordsResponse recordsResponse = kinesisClient
//							.getRecords(GetRecordsRequest.builder().shardIterator(shardIterator).limit(10).build());
//
//					List<software.amazon.awssdk.services.kinesis.model.Record> records = recordsResponse.records();
//					for (software.amazon.awssdk.services.kinesis.model.Record record : records) {
//						String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//						liveRecords.add(data);
//						System.out.println("Live data: " + data);
//					}
//
//					shardIterator = recordsResponse.nextShardIterator();
//
//					if (records.isEmpty()) {
//						// Sleep for a bit to avoid overwhelming Kinesis with requests
//						Thread.sleep(1000);
//					}
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return liveRecords;
//	}
//
//}
