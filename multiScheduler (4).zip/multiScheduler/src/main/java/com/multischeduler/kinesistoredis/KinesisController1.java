//package com.multischeduler.kinesistoredis;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/api/kinesis")
//public class KinesisController1 {
//
//	@Autowired
//	private KinesisConsumerService1 kinesisConsumerService;
//
//	// ALL RECORDS
//	@GetMapping("/all-records")
//	public ResponseEntity<List<String>> getAllRecords() {
//		List<String> records = kinesisConsumerService.fetchAllDataFromKinesis();
//		return ResponseEntity.ok(records);
//
//	}
//
//	// LIVE RECORDS STREAM
//	@GetMapping("/records-stream")
//	public ResponseEntity<List<String>> getAllStreamRecords() {
//		List<String> records = kinesisConsumerService.fetchLiveDataFromKinesis();
//		return ResponseEntity.ok(records);
//	}
//
//}
