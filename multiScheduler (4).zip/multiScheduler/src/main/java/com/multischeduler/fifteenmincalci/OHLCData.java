package com.multischeduler.fifteenmincalci;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

import java.time.Instant;

@Data
@Document(collection = "5min_data")
public class OHLCData {

	@Id
	private String id;

	@Field("Timestamp")
	private Instant timestamp;

	@Field("IST_Timestamp")
	private Instant istTimestamp;

	private String symbol;
	private int instrument;
	private String duration;
	private double open;
	private double high;
	private double low;
	private double close;
	private int volume;

	private double RSI;
	private double ema;
	private double ema50;
	private double sma;

	private double RSI_15min;
	private double ema50_15min;
	private double ema_15min;
	private double sma_15min;

	private double RSI_60min;
	private double ema50_60min;
	private double ema_60min;
	private double sma_60min;

	private double RSI_day;
	private double ema50_day;
	private double ema_day;
	private double sma_day;

	private double RSI_week;
	private double ema50_week;
	private double ema_week;
	private double sma_week;

	private double RSI_month;
	private double ema50_month;
	private double ema_month;
	private double sma_month;

}
