package com.multischeduler.fifteenmincalci;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.Data;

@Data
@Document(collection = "60min_data")
public class OHLC60MinData {
	@Id
	private String id;

	@Field("Timestamp")
	private String timestamp;

	private String symbol;
	private int instrument;
	private String duration;
	private double open;
	private double high;
	private double low;
	private double close;
	private int volume;

	@Field("IST_Timestamp")
	private Date istTimestamp;

	private double rsi;
	private double ema;
	private double ema50;
	private double sma;

	private double rsiDay;
	private double ema50Day;
	private double emaDay;
	private double smaDay;

	private double rsiWeek;
	private double ema50Week;
	private double emaWeek;
	private double smaWeek;

	private double rsiMonth;
	private double ema50Month;
	private double emaMonth;
	private double smaMonth;

}
