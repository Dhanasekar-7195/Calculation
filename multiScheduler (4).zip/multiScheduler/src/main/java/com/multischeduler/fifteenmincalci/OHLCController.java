package com.multischeduler.fifteenmincalci;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class OHLCController {

	@Autowired
	private OHLCService service;

	@Autowired
	private OHLC60MinRepository ohlc60MinRepository;

	@GetMapping("/ohlc/15min")
	public List<OHLCResponse> get15MinOHLC() {
		return service.calculate15MinOHLC();
	}

	@GetMapping("/fetch")
	public List<OHLC60MinData> fetchData() {
		return ohlc60MinRepository.findAll();
	}

}
