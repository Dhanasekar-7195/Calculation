package com.multischeduler.fifteenmincalci;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OHLCService {

	@Autowired
	private OHLCRepository ohlcRepository;
	
	@Autowired
	private OHLC60MinRepository ohlc60MinRepository;
	
//	public List<OHLCResponse> calculate15MinOHLC() {
//	    List<OHLCData> data = ohlcRepository.findAll();
//	    List<OHLCResponse> ohlcList = new ArrayList<>();
//
//	    // Fetch data from the second API
//	    List<OHLC60MinData> fetchData = ohlc60MinRepository.findAll();
//	    Map<String, OHLC60MinData> fetchDataMap = new HashMap<>();
//
//	    // Map the 60-minute data by their timestamp, using the previous 15-minute interval
//	    for (OHLC60MinData entry : fetchData) {
//	        ZonedDateTime fetchTimestamp = entry.getIstTimestamp().toInstant().atZone(ZoneId.of("Asia/Kolkata"));
//	        int minute = fetchTimestamp.getMinute();
//	        int roundedMinute = (minute / 15) * 15;
//
//	        ZonedDateTime intervalStartDateTime = fetchTimestamp.withMinute(roundedMinute).withSecond(0).withNano(0);
//	        Instant intervalStartTime = intervalStartDateTime.toInstant();
//
//	        // Store the previous 15-minute data
//	        fetchDataMap.put(intervalStartTime.toString(), entry);
//	    }
//
//	    double open = 0, high = Double.MIN_VALUE, low = Double.MAX_VALUE, close = 0;
//	    Instant intervalStart = null;
//
//	    for (OHLCData entry : data) {
//	        // Assuming entry.getIstTimestamp() is an Instant
//	        ZonedDateTime dateTime = entry.getIstTimestamp().atZone(ZoneId.of("Asia/Kolkata"));
//	        int minute = dateTime.getMinute();
//	        int roundedMinute = (minute / 15) * 15;
//
//	        ZonedDateTime intervalStartDateTime = dateTime.withMinute(roundedMinute).withSecond(0).withNano(0);
//	        Instant intervalStartTime = intervalStartDateTime.toInstant();
//
//	        // Fetch corresponding 60-minute data (1 hour before)
//	        Instant previousHourStart = intervalStartTime.minus(1, ChronoUnit.HOURS);
//	        OHLC60MinData correspondingFetchData = fetchDataMap.get(previousHourStart.toString());
//
//	        if (intervalStart == null || !intervalStart.equals(intervalStartTime)) {
//	            if (intervalStart != null) {
//	                // Add response with the corresponding 60-minute data or default to 0.0
//	                ohlcList.add(new OHLCResponse(
//	                        open, high, low, close, intervalStart,
//	                        correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0,
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0,
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // EMA50 (if different calculation exists)
//	                        correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0, // SMA (if needed)
//	                        correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0, // For rsiValue
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema20Value
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema50Value
//	                        correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0  // For sma200Value
//	                ));
//	            }
//	            intervalStart = intervalStartTime;
//	            open = entry.getClose();
//	            high = entry.getClose();
//	            low = entry.getClose();
//	        }
//
//	        high = Math.max(high, entry.getClose());
//	        low = Math.min(low, entry.getClose());
//	        close = entry.getClose();
//	    }
//
//	    if (intervalStart != null) {
//	        // Add final interval data with the corresponding 60-minute data or default to 0.0
//	        OHLC60MinData correspondingFetchData = fetchDataMap.get(intervalStart.minus(1, ChronoUnit.HOURS).toString());
//	        ohlcList.add(new OHLCResponse(
//	                open, high, low, close, intervalStart,
//	                correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0,
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0,
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // EMA50 (if different calculation exists)
//	                correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0, // SMA (if needed)
//	                correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0, // For rsiValue
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema20Value
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema50Value
//	                correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0  // For sma200Value
//	        ));
//	    }
//
//	    // Calculate any required indicators
//	    calculateRSI(ohlcList);
//	    calculateEMA(ohlcList, 20);
//	    calculateEMA(ohlcList, 50);
//	    calculateSMA(ohlcList, 200);
//
//	    return ohlcList;
//	}

	
//	public List<OHLCResponse> calculate15MinOHLC() {
//	    List<OHLCData> data = ohlcRepository.findAll();
//	    List<OHLCResponse> ohlcList = new ArrayList<>();
//
//	    // Fetch data from the second API (60-min data)
//	    List<OHLC60MinData> fetchData = ohlc60MinRepository.findAll();
//	    Map<String, OHLC60MinData> fetchDataMap = new HashMap<>();
//
//	    // Map the 60-minute data by their timestamp to easily fetch corresponding values
//	    for (OHLC60MinData entry : fetchData) {
//	        ZonedDateTime fetchTimestamp = entry.getIstTimestamp().toInstant().atZone(ZoneId.of("Asia/Kolkata"));
//	        int hour = fetchTimestamp.getHour();
//	        int minute = fetchTimestamp.getMinute();
//	        if (minute == 15) {
//	            fetchDataMap.put(fetchTimestamp.withSecond(0).withNano(0).toString(), entry);
//	        }
//	    }
//
//	    double open = 0, high = Double.MIN_VALUE, low = Double.MAX_VALUE, close = 0;
//	    Instant intervalStart = null;
//
//	    for (OHLCData entry : data) {
//	        // Convert to ZonedDateTime
//	        ZonedDateTime dateTime = entry.getIstTimestamp().atZone(ZoneId.of("Asia/Kolkata"));
//	        int minute = dateTime.getMinute();
//	        int roundedMinute = (minute / 15) * 15;
//
//	        // Start a new interval at the 15-minute mark
//	        ZonedDateTime intervalStartDateTime = dateTime.withMinute(roundedMinute).withSecond(0).withNano(0);
//	        Instant intervalStartTime = intervalStartDateTime.toInstant();
//
//	        // When a new interval starts, save the previous one
//	        if (intervalStart == null || !intervalStart.equals(intervalStartTime)) {
//	            if (intervalStart != null) {
//	                addOHLCResponse(ohlcList, intervalStart, open, high, low, close, fetchDataMap);
//	            }
//	            intervalStart = intervalStartTime;
//	            open = entry.getClose();
//	            high = entry.getClose();
//	            low = entry.getClose();
//	        }
//
//	        // Update high, low, and close for the current interval
//	        high = Math.max(high, entry.getClose());
//	        low = Math.min(low, entry.getClose());
//	        close = entry.getClose();
//	    }
//
//	    // Add the last interval after the loop
//	    if (intervalStart != null) {
//	        addOHLCResponse(ohlcList, intervalStart, open, high, low, close, fetchDataMap);
//	    }
//
//	    // Calculate technical indicators
//	    calculateRSI(ohlcList);
//	    calculateEMA(ohlcList, 20);
//	    calculateEMA(ohlcList, 50);
//	    calculateSMA(ohlcList, 200);
//
//	    return ohlcList;
//	}
//
//	private void addOHLCResponse(List<OHLCResponse> ohlcList, Instant intervalStart, double open, double high, double low, double close, Map<String, OHLC60MinData> fetchDataMap) {
//	    // Look for the corresponding 60-min data
//	    OHLC60MinData correspondingFetchData = fetchDataMap.get(intervalStart.toString());
//	    ohlcList.add(new OHLCResponse(
//	            open, high, low, close, intervalStart,
//	            correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0,
//	            correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Correct the EMA method
//	            correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Correct EMA50 method
//	            correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0, // Correct SMA method
//	            correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0, // For rsiValue
//	            correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema20Value
//	            correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema50Value
//	            correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0  // For sma200Value
//	    ));
//	}

	
//	public List<OHLCResponse> calculate15MinOHLC() {
//	    List<OHLCData> data = ohlcRepository.findAll();
//	    List<OHLCResponse> ohlcList = new ArrayList<>();
//
//	    // Fetch data from the second API
//	    List<OHLC60MinData> fetchData = ohlc60MinRepository.findAll();
//	    Map<String, OHLC60MinData> fetchDataMap = new HashMap<>();
//
//	    // Map the 60-minute data by their timestamp (to easily fetch corresponding values later)
//	    for (OHLC60MinData entry : fetchData) {
//	        ZonedDateTime fetchTimestamp = entry.getIstTimestamp().toInstant().atZone(ZoneId.of("Asia/Kolkata"));
//	        int hour = fetchTimestamp.getHour();
//	        int minute = fetchTimestamp.getMinute();
//	        if (minute == 15) {
//	            fetchDataMap.put(fetchTimestamp.withSecond(0).withNano(0).toString(), entry);
//	        }
//	    }
//
//	    double open = 0, high = Double.MIN_VALUE, low = Double.MAX_VALUE, close = 0;
//	    Instant intervalStart = null;
//
//	    for (OHLCData entry : data) {
//	        // Assuming entry.getIstTimestamp() is an Instant
//	        ZonedDateTime dateTime = entry.getIstTimestamp().atZone(ZoneId.of("Asia/Kolkata"));
//	        int minute = dateTime.getMinute();
//	        int roundedMinute = (minute / 15) * 15;
//
//	        ZonedDateTime intervalStartDateTime = dateTime.withMinute(roundedMinute).withSecond(0).withNano(0);
//	        Instant intervalStartTime = intervalStartDateTime.toInstant();
//
//	        if (intervalStart == null || !intervalStart.equals(intervalStartTime)) {
//	            if (intervalStart != null) {
//	                OHLC60MinData correspondingFetchData = fetchDataMap.get(intervalStart.toString());
//	                ohlcList.add(new OHLCResponse(
//	                        open, high, low, close, intervalStart,
//	                        correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0,
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Replace with the correct method for EMA
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Replace with correct EMA method for EMA50
//	                        correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0, // Replace with the correct method for SMA
//	                        correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0, // For rsiValue
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema20Value
//	                        correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema50Value
//	                        correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0  // For sma200Value
//	                ));
//	            }
//	            intervalStart = intervalStartTime;
//	            open = entry.getClose();
//	            high = entry.getClose();
//	            low = entry.getClose();
//	        }
//
//	        high = Math.max(high, entry.getClose());
//	        low = Math.min(low, entry.getClose());
//	        close = entry.getClose();
//	    }
//
//	    if (intervalStart != null) {
//	        OHLC60MinData correspondingFetchData = fetchDataMap.get(intervalStart.toString());
//	        ohlcList.add(new OHLCResponse(
//	                open, high, low, close, intervalStart,
//	                correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0,
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Replace with the correct method for EMA
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // Replace with correct EMA method for EMA50
//	                correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0, // Replace with the correct method for SMA
//	                correspondingFetchData != null ? correspondingFetchData.getRsi() : 0.0, // For rsiValue
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema20Value
//	                correspondingFetchData != null ? correspondingFetchData.getEma() : 0.0, // For ema50Value
//	                correspondingFetchData != null ? correspondingFetchData.getSma() : 0.0  // For sma200Value
//	        ));
//	    }
//
//	    calculateRSI(ohlcList);
//	    calculateEMA(ohlcList, 20);
//	    calculateEMA(ohlcList, 50);
//	    calculateSMA(ohlcList, 200);
//
//	    return ohlcList;
//	}











	
	public List<OHLCResponse> calculate15MinOHLC() {
	    List<OHLCData> data = ohlcRepository.findAll();
	    List<OHLCResponse> ohlcList = new ArrayList<>();

	    double open = 0, high = Double.MIN_VALUE, low = Double.MAX_VALUE, close = 0;
	    Double previousClose = null;  // Track previous close value
	    Instant intervalStart = null;

	    for (OHLCData entry : data) {
	        ZonedDateTime dateTime = entry.getIstTimestamp().atZone(ZoneId.of("Asia/Kolkata"));
	        int minute = dateTime.getMinute();
	        int roundedMinute = (minute / 15) * 15;

	        ZonedDateTime intervalStartDateTime = dateTime.withMinute(roundedMinute).withSecond(0).withNano(0);
	        Instant intervalStartTime = intervalStartDateTime.toInstant();

	        if (intervalStart == null || !intervalStart.equals(intervalStartTime)) {
	            if (intervalStart != null) {
	                double volume = (previousClose != null) ? close - previousClose : 0.0;
	                volume = Double.parseDouble(String.format("%.2f", volume)); // Round off volume
	                ohlcList.add(new OHLCResponse(open, high, low, close, intervalStart, 0.0, 0.0, 0.0, 0.0, volume));

	                previousClose = close;  // Update previous close
	            }
	            intervalStart = intervalStartTime;
	            open = entry.getClose();
	            high = entry.getClose();
	            low = entry.getClose();
	        }

	        high = Math.max(high, entry.getClose());
	        low = Math.min(low, entry.getClose());
	        close = entry.getClose();
	    }

	    if (intervalStart != null) {
	        double volume = (previousClose != null) ? close - previousClose : 0.0;
	        volume = Double.parseDouble(String.format("%.2f", volume)); // Round off volume
	        ohlcList.add(new OHLCResponse(open, high, low, close, intervalStart, 0.0, 0.0, 0.0, 0.0, volume));
	    }

	    calculateRSI(ohlcList);
	    calculateEMA(ohlcList, 20);
	    calculateEMA(ohlcList, 50);
	    calculateSMA(ohlcList, 200);

	    return ohlcList;
	}
	
//	public List<OHLCResponse> calculate15MinOHLC() {
//        List<OHLCData> data = ohlcRepository.findAll();
//        List<OHLC60MinData> data60Min = ohlc60MinRepository.findAll();
//
//        List<OHLCResponse> ohlcList = new ArrayList<>();
//
//        double open = 0, high = Double.MIN_VALUE, low = Double.MAX_VALUE, close = 0;
//        Double previousClose = null;
//        Instant intervalStart = null;
//
//        // Time mapping
//        Map<String, Integer> timeMapping = Map.of(
//            "09:15", 10,
//            "10:15", 11,
//            "11:15", 12,
//            "12:15", 13,
//            "13:15", 14,
//            "14:15", 15
//        );
//
//        for (OHLCData entry : data) {
//            ZonedDateTime dateTime = entry.getIstTimestamp().atZone(ZoneId.of("Asia/Kolkata"));
//
//            int minute = dateTime.getMinute();
//            int roundedMinute = (minute / 15) * 15;
//
//            ZonedDateTime intervalStartDateTime = dateTime.withMinute(roundedMinute).withSecond(0).withNano(0);
//            Instant intervalStartTime = intervalStartDateTime.toInstant();
//
//            if (intervalStart == null || !intervalStart.equals(intervalStartTime)) {
//                if (intervalStart != null) {
//                    double volume = (previousClose != null) ? close - previousClose : 0.0;
//                    volume = Double.parseDouble(String.format("%.2f", volume));
//
//                    OHLCResponse response = new OHLCResponse(
//                        open, high, low, close, intervalStart, 0.0, 0.0, 0.0, 0.0, volume, 0.0, 0.0, 0.0, 0.0
//                    );
//
//                    // Match time for RSI, EMA, SMA updates
//                    String formattedTime = dateTime.minusHours(1).format(DateTimeFormatter.ofPattern("HH:mm"));
//                    Integer mappedHour = timeMapping.get(formattedTime);
//
//                    if (mappedHour != null) {
//                        OHLC60MinData matching60MinData = findMatching60MinData(data60Min, formattedTime);
//                        if (matching60MinData != null) {
//                            response.setRsiValue(matching60MinData.getRsi());
//                            response.setEma20Value(matching60MinData.getEma());
//                            response.setEma50Value(matching60MinData.getEma50());
//                            response.setSma200Value(matching60MinData.getSma());
//                        }
//                    }
//
//                    ohlcList.add(response);
//                    previousClose = close;
//                }
//
//                intervalStart = intervalStartTime;
//                open = entry.getClose();
//                high = entry.getClose();
//                low = entry.getClose();
//            }
//
//            high = Math.max(high, entry.getClose());
//            low = Math.min(low, entry.getClose());
//            close = entry.getClose();
//        }
//
//        if (intervalStart != null) {
//            double volume = (previousClose != null) ? close - previousClose : 0.0;
//            volume = Double.parseDouble(String.format("%.2f", volume));
//
//            OHLCResponse finalResponse = new OHLCResponse(
//                open, high, low, close, intervalStart, 0.0, 0.0, 0.0, 0.0, volume, 0.0, 0.0, 0.0, 0.0
//            );
//            ohlcList.add(finalResponse);
//        }
//
//        calculateRSI(ohlcList);
//        calculateEMA(ohlcList, 20);
//        calculateEMA(ohlcList, 50);
//        calculateSMA(ohlcList, 200);
//
//        return ohlcList;
//    }
//
//    /**
//     * Match 60-minute data by formatted time (HH:mm)
//     */
//	private OHLC60MinData findMatching60MinData(List<OHLC60MinData> data60Min, String formattedTime) {
//	    for (OHLC60MinData entry : data60Min) {
//	        ZonedDateTime entryTime = entry.getIstTimestamp().toInstant().atZone(ZoneId.of("Asia/Kolkata"));
//	        String entryFormattedTime = entryTime.format(DateTimeFormatter.ofPattern("HH:mm"));
//
//	        // 🔥 Log the timestamps for debugging
//	        System.out.println("🔍 Checking 60Min Data Time: " + entryFormattedTime + " against Interval Time: " + formattedTime);
//
//	        if (entryFormattedTime.equals(formattedTime)) {
//	            System.out.println("✅ Match Found for Time: " + formattedTime);
//	            return entry;
//	        }
//	    }
//	    System.out.println("❌ No Match Found for Time: " + formattedTime);
//	    return null;
//	}

    
//    public List<OHLCResponse> calculate15MinOHLC() {
//        List<OHLCData> data = ohlcRepository.findAll();
//        List<OHLC60MinData> data60Min = ohlc60MinRepository.findAll();
//
//        System.out.println("📊 Total 15Min Records: " + data.size());
//        System.out.println("📊 Total 60Min Records: " + data60Min.size());
//
//        if (data.isEmpty() || data60Min.isEmpty()) {
//            System.out.println("❗ Data not loaded properly. Check database or repository.");
//        }
//        return Collections.emptyList();
//        }
    





	
	

	private void calculateSMA(List<OHLCResponse> ohlcList, int period) {
		for (int i = 0; i <= ohlcList.size() - period; i++) {
			double sum = 0.0;
			for (int j = 0; j < period; j++) {
				sum += ohlcList.get(i + j).getClose();
			}
			double sma = sum / period;
			sma = Double.parseDouble(String.format("%.2f", sma));
			ohlcList.get(i + period - 1).setSma200(sma);
		}
	}

	private void calculateRSI(List<OHLCResponse> ohlcList) {
		int period = 14;
		List<Double> closePrices = new ArrayList<>();

		for (OHLCResponse ohlc : ohlcList) {
			closePrices.add(ohlc.getClose());
		}

		double avgGain = 0, avgLoss = 0;

		for (int i = 1; i <= period; i++) {
			double change = closePrices.get(i) - closePrices.get(i - 1);
			double gain = Math.max(change, 0);
			double loss = Math.max(-change, 0);
			avgGain += gain;
			avgLoss += loss;
		}

		avgGain /= period;
		avgLoss /= period;

		double rs = avgLoss == 0 ? 100 : avgGain / avgLoss;
		double initialRSI = 100 - (100 / (1 + rs));
		ohlcList.get(period - 1).setRsi(Double.parseDouble(String.format("%.2f", initialRSI)));

		for (int i = period; i < closePrices.size(); i++) {
			double change = closePrices.get(i) - closePrices.get(i - 1);
			double gain = Math.max(change, 0);
			double loss = Math.max(-change, 0);

			avgGain = ((avgGain * (period - 1)) + gain) / period;
			avgLoss = ((avgLoss * (period - 1)) + loss) / period;

			rs = avgLoss == 0 ? 100 : avgGain / avgLoss;
			double rsi = 100 - (100 / (1 + rs));

			rsi = Double.parseDouble(String.format("%.2f", rsi));
			ohlcList.get(i).setRsi(rsi);
		}
	}

	private void calculateEMA(List<OHLCResponse> ohlcList, int period) {
		double multiplier = 2.0 / (period + 1);
		Double previousEMA = null;

		for (int i = 0; i < ohlcList.size(); i++) {
			double close = ohlcList.get(i).getClose();

			if (i + 1 == period) {
				double sma = 0;
				for (int j = 0; j < period; j++) {
					sma += ohlcList.get(j).getClose();
				}
				previousEMA = sma / period;
				previousEMA = Double.parseDouble(String.format("%.2f", previousEMA));
				if (period == 20)
					ohlcList.get(i).setEma20(previousEMA);
				if (period == 50)
					ohlcList.get(i).setEma50(previousEMA);
			} else if (i + 1 > period && previousEMA != null) {
				previousEMA = ((close - previousEMA) * multiplier) + previousEMA;
				previousEMA = Double.parseDouble(String.format("%.2f", previousEMA));
				if (period == 20)
					ohlcList.get(i).setEma20(previousEMA);
				if (period == 50)
					ohlcList.get(i).setEma50(previousEMA);
			}
		}
	}
}
