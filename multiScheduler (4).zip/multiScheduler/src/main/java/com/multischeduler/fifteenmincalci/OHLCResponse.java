package com.multischeduler.fifteenmincalci;

import java.time.Instant;

import lombok.Data;

@Data
public class OHLCResponse {
	private double open;
	private double high;
	private double low;
	private double close;
	private Instant istTimestamp;
	private double rsi;
	private double ema20;
	private double ema50;
	private double sma200;
	private double volume;

//	private double rsiValue; // Renamed rsi field
//	private double ema50Value; // Renamed ema50 field
//	private double ema20Value; // You can keep ema20 if needed
//	private double sma200Value;

	public OHLCResponse(double open, double high, double low, double close, Instant istTimestamp, double rsi,
			double ema20, double ema50, double sma200, double volume) {
			//double rsiValue, double ema20Value, double ema50Value, double sma200Value) {
	//, double rsiValue, double ema20Value, double ema50Value,
			//double sma200Value) {
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close;
		this.istTimestamp = istTimestamp;
		this.rsi = rsi;
		this.ema20 = ema20;
		this.ema50 = ema50;
		this.sma200 = sma200;
		this.volume = volume;

//		this.rsiValue = rsiValue;
//		this.ema50Value = ema50Value;
//		this.ema20Value = ema20Value;
//		this.sma200Value = sma200Value;

	}
}