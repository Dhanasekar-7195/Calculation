package com.multischeduler.fifteenmincalci;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OHLC60MinRepository extends MongoRepository<OHLC60MinData, String> {

}
