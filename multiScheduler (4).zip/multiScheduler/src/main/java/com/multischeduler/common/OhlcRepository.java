package com.multischeduler.common;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface OhlcRepository extends MongoRepository<OhlcEntity, String> {

	@Aggregation(pipeline = {
			"{ $group: { "
					+ "    _id: { symbol: '$symbol', minute: { $dateTrunc: { date: '$timestamp', unit: 'minute' } } }, "
					+ "    open: { $first: '$ohlc.close' }, " + "    high: { $max: '$ohlc.close' }, "
					+ "    low: { $min: '$ohlc.close' }, " + "    close: { $last: '$ohlc.close' } " + "} }",
			"{ $project: { " + "    _id: 0, " + "    symbol: '$_id.symbol', " + "    minute: '$_id.minute', "
					+ "    open: 1, " + "    high: 1, " + "    low: 1, " + "    close: 1 " + "} }",
			"{ $sort: { minute: 1 } }" // Sort the response by timestamp (minute) in ascending order
	})
	List<OhlcDTO> getOhlcData();
}
