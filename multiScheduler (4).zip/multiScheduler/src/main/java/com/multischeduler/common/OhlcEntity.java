package com.multischeduler.common;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "Dhanas") // Change to your MongoDB collection name
public class OhlcEntity {
	@Id
	private String id;
	private Instant timestamp;
	private String symbol;
	private long instrumentToken;
	private double lastPrice;
	private Ohlc ohlc;
	private long volume;

	@Data
	public static class Ohlc {
		private double open;
		private double high;
		private double low;
		private double close;
	}
}
