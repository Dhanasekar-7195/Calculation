package com.multischeduler.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ohlc")
public class OhlcController {

	@Autowired
	private OhlcService ohlcService;

	@GetMapping("/all")
	public List<OhlcDTO> getAllOhlc() {
		return ohlcService.getOhlcData();
	}
}
