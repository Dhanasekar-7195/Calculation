package com.multischeduler.common;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

@Data
@AllArgsConstructor
public class OhlcDTO implements Serializable {
    private String symbol;
    private Instant minute;
    private double open;
    private double high;
    private double low;
    private double close;
}

