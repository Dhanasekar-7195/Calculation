package com.multischeduler.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OhlcService {

//	@Autowired
//	private OhlcRepository ohlcRepository;
//
//	public List<OhlcDTO> getOhlcData() {
//		return ohlcRepository.getOhlcData();
//	}

	@Autowired
	private OhlcRepository ohlcRepository;

	@Autowired
	private RedisTemplate<String, List<OhlcDTO>> redisTemplate;

	private static final String CACHE_KEY = "OHLC_DATA";

	// Fetch OHLC data (first request fetches from DB, next from Redis)
	@Cacheable(value = "ohlcCache", key = "'OHLC_DATA'")
	public List<OhlcDTO> getOhlcData() {
		List<OhlcDTO> ohlcData = ohlcRepository.getOhlcData();
		redisTemplate.opsForValue().set(CACHE_KEY, ohlcData);
		return ohlcData;
	}

	// Auto-refresh Redis every 1 minute with latest MongoDB data
	@Scheduled(fixedRate = 60000) // Runs every 60 seconds (1 min)
	@CacheEvict(value = "ohlcCache", key = "'OHLC_DATA'")
	public void refreshCache() {
		System.out.println("Refreshing Redis Cache with latest MongoDB data...");
		List<OhlcDTO> latestData = ohlcRepository.getOhlcData();
		redisTemplate.opsForValue().set(CACHE_KEY, latestData);
	}
}
