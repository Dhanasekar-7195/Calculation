//package com.multischeduler.kinesis;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Service;
//
//import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
//import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
//import software.amazon.awssdk.regions.Region;
//import software.amazon.awssdk.services.kinesis.KinesisClient;
//import software.amazon.awssdk.services.kinesis.model.*;
//import software.amazon.awssdk.services.kinesis.model.Record;
//
//import java.nio.charset.StandardCharsets;
//import java.util.ArrayList;
//import java.util.List;
//
//@Service
//public class KinesisConsumerService {
//
//	@Autowired
//	private StringRedisTemplate redisTemplate;
//
//	private final KinesisClient kinesisClient;
//	private final ObjectMapper objectMapper = new ObjectMapper();
//	private final String streamName = "kiteconnect-data";
//
//	public KinesisConsumerService() {
//		this.kinesisClient = KinesisClient.builder().region(Region.of("ap-south-1"))
//				.credentialsProvider(StaticCredentialsProvider.create(
//						AwsBasicCredentials.create("AKIAS74TMCZ77HWYGTNA", "m+vgLlWaH0VMNilwAUn4nORgfdLbD+mne48W2Oy5")))
//				.build();
//
//	}
//
//	public void consumeAndStoreInRedis() {
//		try {
//			// Get the stream description
//			DescribeStreamResponse describeStreamResponse = kinesisClient
//					.describeStream(DescribeStreamRequest.builder().streamName(streamName).build());
//
//			List<Shard> shards = describeStreamResponse.streamDescription().shards();
//
//			for (Shard shard : shards) {
//				String shardIterator = getShardIterator(shard.shardId());
//
//				while (shardIterator != null) {
//					// Fetch records from Kinesis
//					GetRecordsResponse recordsResponse = kinesisClient
//							.getRecords(GetRecordsRequest.builder().shardIterator(shardIterator).limit(10).build());
//
//					List<Record> records = recordsResponse.records();
//					for (Record record : records) {
//						String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//						processAndStore(data);
//					}
//
//					// Move to the next batch
//					shardIterator = recordsResponse.nextShardIterator();
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	private String getShardIterator(String shardId) {
//		GetShardIteratorRequest request = GetShardIteratorRequest.builder().streamName(streamName).shardId(shardId)
//				.shardIteratorType(ShardIteratorType.LATEST) // Fetch new data as it comes in
//				.build();
//
//		GetShardIteratorResponse response = kinesisClient.getShardIterator(request);
//		return response.shardIterator();
//	}
//
//	private void processAndStore(String data) {
//		try {
//			// Parse the data (if JSON)
//			JsonNode jsonNode = objectMapper.readTree(data);
//
//			// Example: Store in Redis (as a simple key-value)
//			String key = jsonNode.get("id").asText(); // Use a unique ID
//			redisTemplate.opsForValue().set(key, data);
//
//			System.out.println("Stored in Redis: " + key);
//		} catch (Exception e) {
//			System.err.println("Failed to process record: " + e.getMessage());
//		}
//	}
//
//	
//	
//	
//	
//	
//	
//	
//	public List<String> fetchLiveDataFromKinesis() {
//	    List<String> liveRecords = new ArrayList<>();
//	    try {
//	        DescribeStreamResponse describeStreamResponse = kinesisClient
//	                .describeStream(DescribeStreamRequest.builder().streamName(streamName).build());
//
//	        List<Shard> shards = describeStreamResponse.streamDescription().shards();
//
//	        for (Shard shard : shards) {
//	            String shardIterator = getShardIterator(shard.shardId());
//
//	            if (shardIterator != null) {
//	                GetRecordsResponse recordsResponse = kinesisClient
//	                        .getRecords(GetRecordsRequest.builder().shardIterator(shardIterator).limit(10).build());
//
//	                List<Record> records = recordsResponse.records();
//	                for (Record record : records) {
//	                    String data = StandardCharsets.UTF_8.decode(record.data().asByteBuffer()).toString();
//	                    liveRecords.add(data);
//	                }
//	            }
//	        }
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }
//	    return liveRecords;
//	}
//}
