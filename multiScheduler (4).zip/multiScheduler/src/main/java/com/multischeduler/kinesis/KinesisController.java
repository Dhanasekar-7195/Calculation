//package com.multischeduler.kinesis;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Set;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/api")
//public class KinesisController {
//	@Autowired
//	private KinesisConsumerService kinesisConsumerService;
//
//	@Autowired
//	private StringRedisTemplate redisTemplate;
//
//	@GetMapping("/records")
//	public ResponseEntity<List<String>> getAllRecords() {
//		List<String> records = new ArrayList<>();
//
//		// Fetch all keys from Redis
//		Set<String> keys = redisTemplate.keys("*");
//		if (keys != null && !keys.isEmpty()) {
//			for (String key : keys) {
//				String value = redisTemplate.opsForValue().get(key);
//				records.add(value);
//			}
//		}
//
//		return ResponseEntity.ok(records);
//	}
//	
//	
//	
//	
//	
//	
//	@GetMapping("/live-records")
//    public ResponseEntity<List<String>> fetchLiveRecords() {
//        List<String> liveRecords = kinesisConsumerService.fetchLiveDataFromKinesis();
//        return ResponseEntity.ok(liveRecords);
//    }
//	}
