//package com.multischeduler.kinesis;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//@Component
//public class KinesisPollingScheduler {
//
//	@Autowired
//	private KinesisConsumerService kinesisConsumerService;
//
//	@Scheduled(fixedRate = 5000) // Poll every 5 seconds
//	public void pollKinesis() {
//		System.out.println("Polling Kinesis for new records...");
//		kinesisConsumerService.consumeAndStoreInRedis();
//	}
//}
