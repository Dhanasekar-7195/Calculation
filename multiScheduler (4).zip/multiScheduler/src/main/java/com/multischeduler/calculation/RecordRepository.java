package com.multischeduler.calculation;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface RecordRepository extends MongoRepository<Record, String> {
	List<Record> findAllByOrderByDateAsc();

}
