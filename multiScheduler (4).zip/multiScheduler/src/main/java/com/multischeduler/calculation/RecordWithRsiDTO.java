package com.multischeduler.calculation;

import lombok.Data;

@Data
public class RecordWithRsiDTO {
	private Record record;
	private double rsi;
	private Double ema20;
	private Double ema50;
	private Double sma200;

	// Constructor
	public RecordWithRsiDTO(Record record, double rsi, Double ema20, Double ema50, Double sma200) {
		this.record = record;
		this.rsi = rsi;
		this.ema20 = ema20;
		this.ema50 = ema50;
		this.sma200 = sma200;
	}
}
