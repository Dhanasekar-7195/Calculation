package com.multischeduler.calculation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RsiService {
	@Autowired
	private RecordRepository recordRepository;

	public List<RecordWithRsiDTO> getRecordsWithRsi() {
		List<Record> records = recordRepository.findAllByOrderByDateAsc();
		return calculateIndicators(records);
	}

	private List<RecordWithRsiDTO> calculateIndicators(List<Record> records) {
		List<RecordWithRsiDTO> result = new ArrayList<>();
		Double ema20 = null;
		Double ema50 = null;

		for (int i = 13; i < records.size(); i++) {
			List<Record> window = records.subList(i - 13, i + 1);
			double rsi = calculateRsiForWindow(window);

			// Start EMA 20 calculation from record 21
			if (i >= 19) {
				ema20 = calculateEma(records, i, 20, ema20);
			}

			// Start EMA 50 calculation from record 51
			if (i >= 49) {
				ema50 = calculateEma(records, i, 50, ema50);
			}

			double sma200 = calculateSma(records, i, 200);

			result.add(new RecordWithRsiDTO(records.get(i), rsi, ema20, ema50, sma200));
		}
		return result;
	}

	private double calculateRsiForWindow(List<Record> window) {
		double gain = 0, loss = 0;
		for (int i = 1; i < window.size(); i++) {
			double change = window.get(i).getClose() - window.get(i - 1).getClose();
			if (change > 0)
				gain += change;
			else
				loss -= change;
		}
		double avgGain = gain / 13;
		double avgLoss = loss / 13;
		double rs = avgLoss == 0 ? 100 : avgGain / avgLoss;
		return 100 - (100 / (1 + rs));
	}

	private Double calculateEma(List<Record> records, int index, int period, Double previousEma) {
		double multiplier = 2.0 / (period + 1);
		if (index < period - 1)
			return null;

		if (previousEma == null) {
			double sum = 0;
			for (int i = index - period + 1; i <= index; i++) {
				sum += records.get(i).getClose();
			}
			return sum / period;
		}
		double currentPrice = records.get(index).getClose();
		return (currentPrice * multiplier) + (previousEma * (1 - multiplier));
	}

	private double calculateSma(List<Record> records, int index, int period) {
		if (index < period - 1)
			return 0;
		double sum = 0;
		for (int i = index - period + 1; i <= index; i++) {
			sum += records.get(i).getClose();
		}
		return sum / period;
	}
}
