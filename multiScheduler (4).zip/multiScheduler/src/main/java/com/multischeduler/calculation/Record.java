package com.multischeduler.calculation;

import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.persistence.Id;
import lombok.Data;

@Data
@Document(collection = "5min_candles")
public class Record {
	@Id
	private String id;
	private String Date;
	private double Open;
	private double High;
	private double Low;
	private double Close;

}
